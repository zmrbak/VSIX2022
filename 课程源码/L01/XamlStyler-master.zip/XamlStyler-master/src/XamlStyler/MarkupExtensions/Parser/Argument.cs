// (c) Xavalon. All rights reserved.

namespace Xavalon.XamlStyler.MarkupExtensions.Parser
{
    public abstract class Argument
    {
    }
}