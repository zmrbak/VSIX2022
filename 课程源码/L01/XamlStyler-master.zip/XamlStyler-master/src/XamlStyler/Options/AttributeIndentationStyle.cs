﻿// (c) Xavalon. All rights reserved.

namespace Xavalon.XamlStyler.Options
{
    public enum AttributeIndentationStyle
    {
        Mixed,
        Spaces,
    }
}