// (c) Xavalon. All rights reserved.

namespace Xavalon.XamlStyler.Options
{
    public enum VisualStateManagerRule
    {
        None,
        First,
        Last,
    }
}