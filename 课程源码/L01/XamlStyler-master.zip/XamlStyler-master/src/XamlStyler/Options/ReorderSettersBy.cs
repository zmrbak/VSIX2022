// (c) Xavalon. All rights reserved.

namespace Xavalon.XamlStyler.Options
{
    public enum ReorderSettersBy
    {
        None,
        Property,
        TargetName,
        TargetNameThenProperty,
    }
}