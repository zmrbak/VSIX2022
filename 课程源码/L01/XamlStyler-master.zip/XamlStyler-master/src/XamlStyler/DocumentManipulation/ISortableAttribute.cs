// (c) Xavalon. All rights reserved.

using System;

namespace Xavalon.XamlStyler.DocumentManipulation
{
    public interface ISortableAttribute : IComparable<ISortableAttribute>
    {
    }
}