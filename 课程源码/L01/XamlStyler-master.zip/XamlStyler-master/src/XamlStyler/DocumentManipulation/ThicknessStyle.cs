// (c) Xavalon. All rights reserved.

namespace Xavalon.XamlStyler.DocumentManipulation
{
    public enum ThicknessStyle
    {
        None,
        Space,
        Comma
    }
}