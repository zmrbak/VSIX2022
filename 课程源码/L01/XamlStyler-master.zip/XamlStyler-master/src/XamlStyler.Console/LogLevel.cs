﻿// © Xavalon. All rights reserved.

namespace Xavalon.XamlStyler.Console
{
    public enum LogLevel
    {
        None = 0,
        Minimal = 1,
        Default = 2,
        Verbose = 3,
        Debug = 4,
        Insanity = 5,
    }
}