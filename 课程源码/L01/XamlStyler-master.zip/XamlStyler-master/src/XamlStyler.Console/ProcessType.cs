﻿// © Xavalon. All rights reserved.

namespace Xavalon.XamlStyler.Console
{
    public enum ProcessType
    {
        File,
        Directory,
    }
}