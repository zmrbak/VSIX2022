Check out our [release](https://github.com/Xavalon/XamlStyler/releases) page for a full history of changes.
