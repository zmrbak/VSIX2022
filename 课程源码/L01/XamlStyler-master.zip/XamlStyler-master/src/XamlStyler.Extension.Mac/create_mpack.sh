#!/bin/sh

"/Applications/Visual Studio.app/Contents/MacOS/vstool" setup pack bin/Release/XamlStyler.Mac.dll
